# A function for adding
def Add(x_in, y_in):
    sum_out = x_in + y_in
    
    return (sum_out)
    
# A function for squaring
def Square(x_in):
    x2_out = (x_in * x_in)
    
    return (x2_out)
    
c = pow( Add(Square(3), Square(4)) , 0.5 )
print (c)