def DecToBin(d):
    myList = []
    i = 0
    
    if (d < 1):
        myList.append(0)
        
    
    while (d != 0):
        if (d % 2 == 0):
            myList.append(1)
            d = (int(d / 2))
            
        else:
            myList.append(0)
            d = (int((d - 1) / 2))
    
    for i in reversed(myList):
        print (i)
    
    #print (myList)