def ParityParty(d):
    myList = ['0', '1']
    i = 0
    
    if (d > -1):
        if (d % 2 == 0):
            myList[i] = 0
            i = i + 1
            d = (int(d / 2))
            myList[i] = d
            
            return (myList)
            
        
        else:
            myList[i] = 1
            i = i + 1
            d = (int((d - 1) / 2))
            myList[i] = d
            
            return (myList)
        
        
print (ParityParty(34))