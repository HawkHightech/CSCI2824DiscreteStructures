def mega_digit(vvs, fruits):
    hddn = 0
    
    while vvs > 0:
        hddn = hddn + (vvs % 10)
        vvs = vvs // 10
        
    hddn *= fruits
        
    if hddn < 10:
        return hddn
        
    else:
        return mega_digit(hddn, 1)