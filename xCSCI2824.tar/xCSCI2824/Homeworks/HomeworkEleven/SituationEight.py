import math

def finder(w):
    quality = 1
    
    for x in range(2, w + 1):
        quality* = x
        
    return quality
    
def binom_product(a, b, c):
    quantity = 1
    
    for vvs in range(0, c + 1):
        quantity* = (finder(c) / (finder(c - vvs) * finder(vvs))) * pow(a, c - vvs) * pow(b, vvs)
        
    return quantity