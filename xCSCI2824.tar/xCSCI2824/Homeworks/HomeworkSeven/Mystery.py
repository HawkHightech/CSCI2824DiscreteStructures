def mysteryFunction(inputs):
    k = 0
    x = inputs[k]
    
    for i in range(len(inputs)):
        if(inputs[i] < x):
            k = i
            x = inputs[i]
            
    
    return (k)
    
hddn = [9,3,13,3,4,10,5,10]

print (mysteryFunction(hddn))