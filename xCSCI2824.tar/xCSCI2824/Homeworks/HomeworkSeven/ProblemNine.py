def sequence_slayer(N):
    hddn = []
    aKnot = 1
    aOne = 2
    hddn.append(aKnot)
    hddn.append(aOne)
        
    if (N == 0):
        return aKnot
        
    if(N > 0 and N < 50):
        if(N == 1):
            return aOne
            
        else:
            for w in range (1, N):
                H = (((w + 1) ** 2) * hddn[w]) - (hddn[w - 1])
                #print ("w: ", w)
                #print ("H: ", H)
                hddn.append(H)
    
    #print (hddn)    
    return hddn[-1]
            
        