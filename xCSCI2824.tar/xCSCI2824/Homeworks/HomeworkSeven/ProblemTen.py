def first_D_digit_Lucas(D):
    Luc = []
    Luc.append(2)
    Luc.append(1)
    
    for n in range (2, 777):
        Luc.append(Luc[n - 1] + Luc[n - 2])
        
        
    for w in range (0, len(Luc)):
        if len(str(Luc[w])) == D:
            return Luc[w]