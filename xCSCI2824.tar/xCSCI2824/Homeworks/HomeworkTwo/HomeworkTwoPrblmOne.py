def D(i, n):
    A = [4, 8, 15, 16, 23, 42]
    
    if (A[i] % n == 0):
        return "True"
            
    return "False"