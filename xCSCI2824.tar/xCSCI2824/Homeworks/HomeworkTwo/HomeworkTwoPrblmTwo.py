def check_proposition(list):
    w = 0
    m = 0
    
    for x in list: #For all of the numbers in the list
        if (x % 2 == 0):
            w = w + 1
            
            for y in list:
                if (x == 2 * y):
                    m = m + 1
            
                    
    if (w == m):
        return "True"
        
    else:
        return "False"
        